from django.contrib import admin
from .models import contact,SaveFile,SavePhoto
# from .models import signup
# # Register your models here.
# @admin.register(signup)
# class signup(admin.ModelAdmin):
#     list_display=('id','name','email','dob','gender','mobile','pass1','pass2') # ise django admin me data show hota hai

@admin.register(contact)
class contact(admin.ModelAdmin):
    list_display=['id','fullname','email','mobile','comment']

@admin.register(SaveFile)
class SaveFileAdmin(admin.ModelAdmin):
    list_display=['id','name','my_file']

@admin.register(SavePhoto)
class SavePhotoAdmin(admin.ModelAdmin):
    list_display=['id','name','profile_image']