from django.contrib.auth.models import User
from django import forms
from .models import contact,SavePhoto,SaveFile
from django.contrib.auth.forms import UserCreationForm,UserChangeForm,AuthenticationForm,PasswordChangeForm

class SignUpForm(UserCreationForm):
    password2=forms.CharField(label='Confirm Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password1=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    class Meta:
        model=User
        fields=['username','first_name','last_name','email']
        labels={'username':'Username','first_name':'First Name','last_name':'Last Name','email':'Email ID'}
        widgets={
                    'username':forms.TextInput(attrs={'class':'form-control'}),
                    'first_name':forms.TextInput(attrs={'class':'form-control'}),
                    'last_name':forms.TextInput(attrs={'class':'form-control'}),
                    'email':forms.EmailInput(attrs={'class':'form-control'}),
                }
class EditUserProfileForm(UserChangeForm):
    password=None
    class Meta:
        model=User
        fields=['username','first_name','last_name','email','date_joined','last_login']
        labels={'email':'Email ID'}
        widgets={
            'username':forms.TextInput(attrs={'class':'form-control'}),
            'first_name':forms.TextInput(attrs={'class':'form-control'}),
            'last_name':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'date_joined':forms.DateInput(attrs={'class':'form-control'}),
            'last_login':forms.TextInput(attrs={'class':'form-control'}),
        }


class ContactForm(forms.ModelForm):
    class Meta:
        model=contact
        fields=['fullname','email','mobile','comment']
        labels={'email':'Email ID','fullname':'Full Name'}
        widgets={
            'fullname':forms.TextInput(attrs={'class':'form-control'}),
            'email':forms.EmailInput(attrs={'class':'form-control'}),
            'mobile':forms.TextInput(attrs={'class':'form-control'}),
            'comment':forms.Textarea(attrs={'class':'form-control','rows':4, 'cols':15}),
        }

class LoginUserForm(AuthenticationForm):
    username=forms.CharField(label='User Name',widget=forms.TextInput(attrs={'class':'form-control'}))
    password=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control'}))


class SaveFileForm(forms.ModelForm):
    class Meta:
        model=SaveFile
        fields=['id','name','my_file']
        labels={'name':'File Name','my_file':'Document'}

# form-control se form pe bootstrap ka css lagta hai 

        widgets={
                    'name':forms.TextInput(attrs={'class':'form-control'}),   
                }

class SavePhotoForm(forms.ModelForm):
    class Meta:
        model=SavePhoto
        fields=['id','name','profile_image']
        labels={'name':'Photo Name','profile_image':'Image'}
 

        widgets={
                    'name':forms.TextInput(attrs={'class':'form-control'}),   
                }

class ChangePassword(PasswordChangeForm):
    fields=['old_password','new_password1','new_password2']
    labels={'old_password':'Old Password','new_password1':'New Password','new_password2':'Confirm Password'}
    widgets={
        'old_password':forms.PasswordInput(attrs={'class':'form-control'}),
        'new_password1':forms.PasswordInput(attrs={'class':'form-control'}),
        'new_password2':forms.PasswordInput(attrs={'class':'form-control'}),
    }