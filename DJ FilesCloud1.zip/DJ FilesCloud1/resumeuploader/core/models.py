from django.db import models

class contact(models.Model):
    fullname=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    mobile=models.CharField(max_length=100)
    comment=models.CharField(max_length=500)
    
class SaveFile(models.Model):
    name=models.CharField(max_length=100)
    my_file=models.FileField(upload_to='doc',blank=True) 

class SavePhoto(models.Model):
    name=models.CharField(max_length=100)
    profile_image=models.ImageField(upload_to='profileimg',blank=True)
    



