from django.shortcuts import render,redirect,HttpResponseRedirect
from .forms import SignUpForm,EditUserProfileForm,ContactForm,LoginUserForm,SaveFileForm,SavePhotoForm,ChangePassword
from .models import contact,SavePhoto,SaveFile
from django.views import View
from django.contrib import messages
# from django.contrib.auth.models import User
from django.contrib.auth.forms import UserChangeForm     # AuthenticationForm -LoginUserForm,PasswordChangeForm
from django.contrib.auth import authenticate,login,logout,update_session_auth_hash


def user_signup(request):
    if request.method=="POST":
        fm=SignUpForm(request.POST)
        if fm.is_valid():
            messages.success(request,"Account Register Successfully !")
            fm.save()
            return HttpResponseRedirect('/profile/')
    else:
        fm=SignUpForm()
    return render(request,'core/signup.html',{'form':fm})

def user_login(request):
    # if not request.user.is_authenticated:

    if request.method=="POST":
        fm=LoginUserForm(request=request,data=request.POST)
        if fm.is_valid():
            uname=fm.cleaned_data['username']   # ye form se data leta hai
            upass=fm.cleaned_data['password']
            user=authenticate(username=uname,password=upass)
            if user is not None:
                login(request,user)
                # return HttpResponseRedirect('/profile/')
                return render(request,'core/profile.html',{'name':request.user})
    else:
        fm=LoginUserForm()

    return render(request,'core/login.html',{'form':fm})
    # else:
    #     return HttpResponseRedirect('/profile/')


def user_logout(request):
    logout(request)
    return HttpResponseRedirect('/login/')

def change_password(request):
    if request.user.is_authenticated:
        if request.method=="POST":
            fm=ChangePassword(user=request.user,data=request.POST)
            if fm.is_valid():
                fm.save()
                update_session_auth_hash(request,fm.user)
                return HttpResponseRedirect('/profile/')

        else:
            fm=ChangePassword(user=request.user)
        return render(request,'core/change_password.html',{'form':fm})
    else:
        return HttpResponseRedirect('/login/')

def profile(request):
    if request.user.is_authenticated:
        # fm=UserChangeForm(instance=request.POST)       
        return render(request,'core/profile.html',{'name':request.user})
    else:
        return HttpResponseRedirect('/login/')

# def edit_profile(request):
#     if request.user.is_authenticated:
#         fm=UserChangeForm(instance=request.POST)
#         return render(request,'core/profile.html',{'name':request.user,'form':fm})
#     else:
#         return HttpResponseRedirect('/login/')
    

def index(request):
    return render(request,'core/index.html')

def contact(request):
    if request.method=="POST":
        fm=ContactForm(request.POST)
        if fm.is_valid():
            fm.save()
            fm=ContactForm()
    else:
        fm=ContactForm()       
    return render(request,'core/contact.html',{'form':fm})

def team(request):
    return render(request,'core/team.html')



class SaveFileView(View):
    def get(self,request):
        form=SaveFileForm()
        candidates=SaveFile.objects.all()   # for fetching data from Table
        return render(request,'core/files.html',{'candidates':candidates,'form':form})

    def post(self,request):
        form=SaveFileForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
        # return render(request,'myapp/home.html',{'form':form})
        return HttpResponseRedirect('/addfile/',{'form':form})

class CandidateView(View):
    def get(self,request):
        # candidate=SaveFile.objects.get(pk=pk)
        candidate=SaveFile.objects.all()
        return render(request,'core/showfile.html',{'candidate':candidate})

class SavePhotoView(View):
    def get(self,request):
        form=SavePhotoForm()
        candidates=SavePhoto.objects.all()   # for fetching data from Table
        return render(request,'core/photo.html',{'candidates':candidates,'form':form})

    def post(self,request):
        form=SavePhotoForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
        # return render(request,'myapp/home.html',{'form':form})
        return HttpResponseRedirect('/addphoto/',{'form':form})

class PhotoView(View):
    def get(self,request):
        candidate=SavePhoto.objects.all()
        return render(request,'core/showphoto.html',{'candidate':candidate})



def delete_photo(request,id): 
    if request.method=='POST':
        pi=SavePhoto.objects.get(pk=id)
        pi.delete()
    return render(request,'core/showphoto.html')

def delete_File(request,id): 
    if request.method=='POST':
        pi=SaveFile.objects.get(pk=id)
        pi.delete()
    return render(request,'core/Showfile.html')
















# import mysql.connector as sql
# id=''
# fn=''
# dob=''
# gn=''
# mb=''
# em=''
# pwd=''
# file_name=''
# file_data=''
# cfn=''
# cem=''
# cmb=''
# cmt=''
# def index(request):
#     return render(request,'core/index.html')


# def signup(request):
#     global fn,dob,gn,mb,em,ps1,ps2
#     if request.method=="POST":
#         con=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#         cursor=con.cursor()
#         d=request.POST
#         for key,value in d.items():
#             if key=="fname":
#                 fn=value
#             if key=="dob":
#                 dob=value
#             if key=="gender":
#                 gn=value
#             if key=="mobile":
#                 mb=value
#             if key=="email":
#                 em=value
#             if key=="pass1":
#                 ps1=value
#             if key=="pass2":
#                 ps2=value

    
#         qry=("select max(user_id) from user")
#         cursor.execute(qry)
#         data=cursor.fetchone()
#         id=int(data[0])+1
#         c="insert into user Values('{}','{}','{}','{}','{}','{}','{}','{}')".format(id,fn,dob,gn,mb,em,ps1,ps2)
#         cursor.execute(c)
#         con.commit()

#     return render(request,'core/signup.html')


# def login(request):
#     global em,pwd,id
#     if request.method=="POST":
#         m=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#         cursor=m.cursor()
#         d=request.POST
#         for key,value in d.items():
#             if key=="email":
#                 em=value
#             if key=="pass1":
#                 pwd=value
        
#         c="select * from user where email='{}' and pass1='{}'".format(em,pwd)
#         cursor.execute(c)
#         t=tuple(cursor.fetchall())
#         id=t[0][0]
#         fname=t[0][1]
#         d=t[0][2]
#         g=t[0][3]
#         m=t[0][4]
#         e=t[0][5]
#         if t==():
#             return render(request,'core/error.html')
#         else:
#             return render(request,"core/profile.html",{'fn':fname,'db':d,'gn':g,'mb':m,'em':e})

#     return render(request,'core/login.html')

# def contact(request):
#     global cfn,cem,cmb,cmt
#     if request.method=="POST":
#         con=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#         cursor=con.cursor()
#         d=request.POST
#         for key,value in d.items():
#             if key=="fname":
#                 cfn=value
#             if key=="email":
#                 cem=value
#             if key=="mobile":
#                 cmb=value
#             if key=="comment":
#                 cmt=value
#         c="insert into contact Values('{}','{}','{}','{}')".format(cfn,cem,cmb,cmt)
#         cursor.execute(c)
#         con.commit()
#     return render(request,'core/contact.html')

# def team(request):
#     return render(request,'core/team.html')

# def profile(request):
#     global em,pwd
#     # if request.method=="POST":
#     m=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#     cursor=m.cursor()        
#     c="select * from user where email='{}' and pass1='{}'".format(em,pwd)
#     cursor.execute(c)
#     t=tuple(cursor.fetchall())
#     fname=t[0][1]
#     d=t[0][2]
#     g=t[0][3]
#     m=t[0][4]
#     e=t[0][5]
#     return render(request,'core/profile.html',{'fn':fname,'db':d,'gn':g,'mb':m,'em':e})
    
# def add_file(request):
#     global em,pwd,file_name,file_data,id
#     if request.method=="POST":
#         m=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#         cursor=m.cursor()
#         d=request.POST
#         for key,val in d.items():
#             if key=="fname":
#                 file_name=val
#             if key=="file1":
#                 file_data=val
#         qry=("select user_id from user where email='{}' and pass1='{}'".format(em,pwd))
#         cursor.execute(qry)
#         d=cursor.fetchone()
#         id=int(d[0])
#         qry2=("select max(file_id) from addfile")
#         cursor.execute(qry2)
#         data=cursor.fetchone()
#         if data[0] is None:
#             d=0
#         else:
#             d=int(data[0])
#         userid=d+1
#         c="insert into addfile Values('{}','{}','{}','{}')".format(userid,file_name,file_data,id)
#         cursor.execute(c)
#         m.commit()
        

#     return render(request,'core/add_file.html')

# def show_file(request):
#     global em,pwd
#     con=sql.connect(host="localhost",user="root",passwd="root",database='filescloud')
#     cursor=con.cursor()
#     qry=("select user_id from user where email='{}' and pass1='{}'".format(em,pwd))
#     cursor.execute(qry)
#     d=cursor.fetchone()
#     id1=int(d[0])
#     qry2=("select * from addfile where user_id='{}'".format(id1))
#     cursor.execute(qry2)
#     t=cursor.fetchall()
#     return render(request,'core/show.html',{'showfile':t})


    

    















# Create your views here.
# def index(request):
#     return render(request,'core/index.html')


# def signup(request):
#     if request.method=='POST':
#         fm=UserRegistration(request.POST)
#         if fm.is_valid():
#             fm.save()
#             fm=UserRegistration()
#     else:
#         fm=UserRegistration()
        
#     return render(request,'core/signup.html',{'form':fm})

# def signin(request):
#     if request.method=='POST':
#         data=signup.objects.all()
#         for k,v in data.items():
#             if k=="email":
#                 em=v
#             if k=="pass1":
#                 ps1=v
        
        
#     #     fm=LoginForm(request.POST)
#     #     em=request.POST['email']
#     #     ps1=request.POST['pass1']
#     #     user=authenticate(email=em,pass1=ps1)
#     #     if user is not None:
#     #         login(request,user)
#     #         nm=user.name
#     #         return render(request,'core/index.html',{'nm':nm})
#     #     else:
#     #         return redirect('/')
#     # else:
#     #     fm=LoginForm(request.POST)
#     # return render(request,'core/signin.html',{'form':fm})
