"""resumeuploader URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
# from myapp import views as myappview
from core import views as coreview
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('addfile/', coreview.SaveFileView.as_view(),name='addfile'),  # Here use Class view 
    path('candidate/',coreview.CandidateView.as_view(),name='candidate'),
    path('addphoto/', coreview.SavePhotoView.as_view(),name='addphoto'),  # Here use Class view 
    path('showphoto',coreview.PhotoView.as_view(),name='showphoto'),


# Yaha se core app ka Url likha gaya hai
    path('',coreview.index,name="index"),
    path('signup/',coreview.user_signup,name="signup"),
    path('login/',coreview.user_login,name="login"),
    path('logout/',coreview.user_logout,name="logout"),
    path('changepass/',coreview.change_password,name='changepassword'),
    path('contact/',coreview.contact,name="contact"),
    path('team/',coreview.team,name="team"),
    path('profile/',coreview.profile,name="profile"),
    path('deletephoto/<int:id>/',coreview.delete_photo,name="deletephoto"),
    path('deletefile/<int:id>/',coreview.delete_File,name="deletefile"),
    # path('editprofile/',coreview.edit_profile,name="editprofile"),

] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
